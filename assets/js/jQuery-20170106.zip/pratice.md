# Bài tập jQuery

1. Hoàn thiện nốt bài todo bằng javascript

2. Làm lại bài todo bằng jQuery

3. Sử dụng bootstrap kết hợp jQuery để validate form: Trạng thái validate màu đỏ giống ở đây http://www.w3schools.com/Bootstrap/bootstrap_forms_inputs2.áp.

Form có các trường thông tin sau: Email, Họ tên, Tuổi. Tất cả các trường đều bắt buộc phải nhập. Nếu chưa nhập thì hiện trạng thái viền đỏ, chữ đỏ lên để người dùng biết.

4. Tạo 1 hình tròn và khi click vào hình tròn đó nó sẽ chuyển động ra xa với tạo độ bất kỳ.

Gợi ý: Sử dụng `animate`